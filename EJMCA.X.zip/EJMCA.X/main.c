
/*
expEYES Junior MCA 1.1
Program : main.c runs on PIC24FV32KA302 micro-controller
Listens on the UART receiver, for commands fom the PC
Author  : Ajith Kumar B.P, ( bpajith at gmail.com , ajith at iuac.res.in)
License : GNU GPL version 3
Started on  18-Feb-2014
Last edit : 30-May-2014
 */


#include <p24FV32KA302.h>
// Configuration : Primary Crystal Oscillator, No PLL, Watchdog OFF
_FICD(ICS_PGx3)
_FDS(DSWDTEN_OFF)
_FWDT(FWDTEN_OFF &WINDIS_OFF )
_FOSC( FCKSM_CSDCMD & POSCFREQ_HS & POSCMOD_HS & OSCIOFNC_ON )
_FOSCSEL( FNOSC_PRI & IESO_OFF  & SOSCSRC_DIG)

#define	GROUPSIZE		40	// Up to 40 commands in each group

// commands without any arguments (1 to 40)
#define GETVERSION	1	// Get the Eyes firmware version
#define READCH0		2       // Reads ADC channel 0
#define STARTHIST	10	// Start histogramming
#define READHIST	11	// Send the histogram to PC, 2 x 256 bytes data
#define CLEARHIST	12	// Send the histogram to PC, 2 x 256 bytes data
#define STOPHIST	13	// Stop histogramming

// Reply from PIC micro to the PC
#define SUCCESS		'D'	// Command executed successfully
#define	INVCMD		'C'	// Invalid Command
#define INVARG		'A'	// Invalid input data
#define INVBUFSIZE	'B'	// Resulting data exceeds buffersize

#define TRUE	1
#define FALSE	0

typedef unsigned char u8;
typedef unsigned int u16;
const char version[] = "em1.1";

#define HISTSIZE     512              //    1024
#define WORDSIZE       2              //    2 byte
u8   dbuf[2+WORDSIZE*HISTSIZE];       // status + pad + histogram data
u16  *iptr = (u16 *)(dbuf);           // Integer pointer
u16  buf_index;
u8   cmd, ch;
u16  ns, adcval, tmp16;
//unsigned long int kk = 0xffeeddcc;
// Assembly language routines
extern void usleep(int);

/*
u16 read_adc11()  // no sleep mode
{
volatile int k=10;
AD1CHS = 11;
IFS0bits.AD1IF = 0;
AD1CON1bits.SAMP = 1;
while(k--) ;   // delay loop
AD1CON1bits.SAMP = 0;
asm("nop");
while(!AD1CON1bits.DONE) ;  // wait for ADC to finish
return ADC1BUF0;
}
 */

void __attribute__((interrupt, no_auto_psv)) _CNInterrupt(void)
{
    AD1CON1bits.SAMP = 1;           // Start Sampling
    if(PORTB & (1 << 3)) 
        {
        //asm("btg LATB,#7");
        IFS1bits.CNIF = 0;          // Clear Interrupt Flag
        return;                     // neglect rising edge
        }
    usleep(5);                      // wait for the SHA output to rise
    AD1CON1bits.SAMP = 0;           // Start AD conversion
    asm("nop");
    asm("nop");
    while(!AD1CON1bits.DONE) ;       // wait for ADC to finish
    adcval = (ADC1BUF0 >> 3) & 511;  // 9 bit resolution only
    //asm("bset LATB,#7");            // Close the SWITCH
    if (adcval > 5)
        {
        ++(*(iptr+adcval+1));   // increment histogram channel
        /*
        if(*(iptr+adcval+1) < 0xffff)
            ++(*(iptr+adcval+1));   // increment histogram channel
        else
            {
            CNEN1bits.CN7IE = 0;    // Disable level chg intr on CN7 (pin7)
            //asm("bclr LATB,#7");    // switch of the LED
            }
         */
        }
    usleep(10);  // extra delay , trying to reduce noise

    asm("bclr LATB,#2");            // Clear BUSY Flag, flipflop
    asm("nop"); asm("nop"); asm("nop"); asm("nop");asm("nop"); asm("nop");
    asm("bset LATB,#2");
    AD1CON1bits.SAMP = 1;           // Back to Sampling mode
    IFS1bits.CNIF = 0;              // Clear Interrupt Flag
}

void init(void)     // Initialize I/O ports, UART, ADC , SPI etc.
{
    ANSA = 1;       // ADC Channel 0 as Analog
    TRISA = 0xffff; // PORTA must be all input, unused pins are grounded.

    ANSB = 0xffff;  // All portB to analog mode
    TRISBbits.TRISB7  = 0;          // OD1 output
    TRISBbits.TRISB11 = 0;          // OC2 - SQR1
    TRISBbits.TRISB10 = 0;          // OC3 - SQR2

    // UART Initialization
    TRISBbits.TRISB1 = 1;   // U2Rx as Input, else it won't work
    ANSBbits.ANSB1 = 0;     // This should be set as Digital Input
    U2MODE = 0x8008;        // enable UART, BRGH, 1 stop bit, No parity
    U2STA = 0x0400;         // Enable Tx
    U2BRG = 3;             // for 16Mhz clock:(38400,51), (115200,16)(3, 500k)

    // ADC Initialization
    AD1CON1 = 0x8402;
    AD1CON2bits.PVCFG = 1;
    AD1CON3bits.ADCS = 3;
    AD1CON5 = 0;
    AD1CSSL = 0;
    AD1CHS = 11;                // Channel 11 is our input
    AD1CON1bits.SAMP = 1;       // leave in sample mode
// reference input ???

    asm("bclr ANSB,  #2");      // Pin 6 to Digital mode, RB2
    asm("bclr TRISB, #2");      // as output, for Flipflop Clearing
    asm("bset LATB,#2");        // make it HIGH
    ANSBbits.ANSB2 = 0;
    TRISBbits.TRISB2 = 0;
    LATBbits.LATB2 = 1;

    asm("bclr ANSB,  #7");      // Pin 16 to Digital mode, RB7
    //asm("bclr TRISB, #7");      // as output, for LED indicator
    //ANSBbits. = 0;
    TRISBbits.TRISB7 = 0;

    //asm("bclr ANSB,  #3");      // Pin 7 to Digital mode, RB3
    //asm("bset CNPU1, #7");      // Pin 7, pullup CN7, for Ext. Interrupt
    ANSBbits.ANSB3 = 0;
    CNPU1bits.CN7PUE = 1;
    }



int main()
{
iptr = (u16*)dbuf;
CLKDIV = 0;                 // No clock division, no DOZE
init();

buf_index = 0;
while(1)
    {
    while(!U2STAbits.URXDA);      // Wait for data from PC
    dbuf[buf_index++] = U2RXREG;

    if(buf_index*GROUPSIZE > dbuf[0])
        {
        cmd = dbuf[0];
        dbuf[0]= SUCCESS;    // Assume success
        buf_index = 1;
        #define SPACE 680
        switch(cmd)         // Command processing starts here
            {
            case GETVERSION:
      		for(ns=0 ; ns < 5; ++ns)
                    dbuf[buf_index++] = version[ns];
      		break;

            case STOPHIST:
                asm("bclr LATB,#7");
                CNEN1bits.CN7IE = 0;    // Disable level chg intr on CN7 (pin7)
                IEC1bits.CNIE = 0;
      		break;

            case STARTHIST:
                asm("bset LATB,#7");
                CNEN1bits.CN7IE = 1;    // Enable level chg intr on CN7 (pin7)
                IEC1bits.CNIE = 1;
                IFS1bits.CNIF = 0;
                asm("bclr LATB,#2");        // Clear the flip flop
                asm("nop");asm("nop");asm("nop");
                asm("bset LATB,#2");
                IFS1bits.CNIF = 0;
		break;

            case READHIST:
    		buf_index = HISTSIZE*WORDSIZE + 2;	// status + pad + 1024 data
      		break;

            case CLEARHIST:
                //asm("bset LATB,#7");
                for(ns = 1; ns < (WORDSIZE*HISTSIZE+2); ++ns)	// Clear the buffer
                    dbuf[ns] = 0;
                break;

            default:
        	dbuf[0] = INVCMD;		// Invalid Command
      		break;
            }

        while(!U2STAbits.TRMT){};   // Wait for Transmit buffer
        U2TXREG = dbuf[0];       // Send the response byte in all cases
	if(dbuf[0] == SUCCESS)   // If no error, send the data bytes
	    for(ns=1; ns < buf_index; ++ns)
                {
    		while(!U2STAbits.TRMT){};   // Wait for Transmit Buffer
                U2TXREG= dbuf[ns];
		}
        buf_index = 0;
        }
    }
}
