
x = [1,2,3]
y = [3,4,5]
import pygrace
pg = pygrace.grace()
#print(pg)  # This line gives error in Python2
pg.plot(x,y)
