from pylab import *

t,v, tt,vv = capture2(300, 100)   # captures A1 and A2
plot(t,v)
plot(tt,vv)
show()
