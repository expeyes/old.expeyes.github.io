from pylab import *
x,y = capture1('A1',10,10)
plot(x,y)
show()
