'''
Connect SINE to A1, with a wire
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

t,v = p.capture(1, 3, 100)
print t   # print time and voltage values
print v

from pylab import *
t,v = p.capture(1, 300, 100)
plot(t,v)
show()
