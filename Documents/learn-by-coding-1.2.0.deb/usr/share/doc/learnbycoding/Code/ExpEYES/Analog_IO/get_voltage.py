'''
Measures voltages connected to A1, A2, IN1 or IN2
Unconnected inputs gives random values due to noise pickup.
'''

import expeyes.eyesj
p = expeyes.eyesj.open()


print p.get_voltage(1)    # A1
print p.get_voltage(2)    # A2
print p.get_voltage(3)    # IN1
print p.get_voltage(4)    # IN2


