'''
Waits for a desired level on a digital input before capturing the waveform
'''

from pylab import *
import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_sqr1(200)
p.enable_wait_low(6)
t,v = p.capture(6, 300, 100)
plot(t,v)

p.enable_wait_high(6)
t,v = p.capture(6, 300, 100)
plot(t,v)

show()
