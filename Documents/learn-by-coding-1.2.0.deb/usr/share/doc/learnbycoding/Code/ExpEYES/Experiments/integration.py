'''
Connect SQR1 to A1. 1k resistor from A1 to A2, 1uF from A2 to ground
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_sqr1(1000)
from pylab import *
t,v, tt,vv = p.capture2_hr(1, 2, 300, 10)  # returns two sets of data, 12 bit resolution
plot(t,v)
plot(tt,vv)
show()

# reverse the positions of R and C to show differentiation. May need to reduce frequency
