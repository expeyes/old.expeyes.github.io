'''
Connect the Transistor Collector to IN1 , 1k resistor from IN1 to PVS
200k resistor from SQR1 to Base , 100 uF from base to GND
'''

from pylab import *
import expeyes.eyesj, time
p = expeyes.eyesj.open()

voltage = []
current = []
f = open('tran_ce.dat','w')

p.set_sqr1_dc(3.0)     # sets 3 volts DC on SQR1 (after RC filtering)

v = 0.0
while v <= 5.0:
  va = p.set_voltage(v)
  time.sleep(0.001)
  vd = p.get_voltage(3)
  i = (va-vd)/1.0   # I in milli Amps
  voltage.append(vd)
  current.append(i)
  ss = '%5.3f\t %5.3f'%(vd,i)
  print ss
  f.write(ss+'\n')
  v = v + 0.050    # 50 mV step

plot(voltage, current)
show()

# modify the program for other characteristics
