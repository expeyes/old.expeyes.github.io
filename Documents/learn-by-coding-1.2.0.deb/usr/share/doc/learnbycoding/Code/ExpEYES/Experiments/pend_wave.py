'''
Connect the DC motor to amplifier input. Output to A1
Oscillate the pendulum and run this code.
'''
from pylab import *
import expeyes.eyesj, time
p = expeyes.eyesj.open()

DURATION = 5
ta = []
va = []
f = open('pend_wave.dat','w')

start = p.get_voltage_time(1)[0]
while 1:
    res = p.get_voltage_time(1)
    tm = res[0] - start			# elapsed time
    ta.append(tm)
    va.append(res[1])
    ss = '%6.3f %6.3f'%(tm,res[1])
    print ss
    f.write(ss+'\n')
    if tm > DURATION:
       break
      
plot(ta,va)
show()

