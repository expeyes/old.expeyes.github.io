'''
Connect SINE to A1, with a wire. Connect a diode from A1 to A2 and a 1k resistor from A2 to GND
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

from pylab import *
p.set_sqrs(150,25)  # Generate 150 Hz Squarewaves on SQR1 and SQR2
res = p.capture4(1, 2, 6,7, 300, 100)  # returns four sets of data
plot(res[0], res[1])   # A1
plot(res[2], res[3])   # A2
plot(res[4], res[5])   # SQR1 readback
plot(res[6], res[7])   # SQR2 readback
show()

