'''
Note the difference in the first item of the values returned, the time stamp
'''

import expeyes.eyesj, time
p = expeyes.eyesj.open()


print p.get_voltage_time(1)    # read A1
time.sleep(0.5)
print p.get_voltage_time(1)    # again after .5 seconds (minimum)


