'''
Connect PVS to IN1
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

# set PVS output. Function returns the readback value
print p.set_voltage(2.5)    
print p.get_voltage(3)      # read IN1


