'''
#Connect 1k resistor from OD1 to A1 and a 1uF capacitor from A1 to ground
'''

from pylab import *
import expeyes.eyesj, expeyes.eyemath as em
p = expeyes.eyesj.open()

p.set_state(10,1)         # OD1 to HIGH
p.enable_set_low(10)
t,v = p.capture_hr(1, 500, 10)
vfit, par = em.fit_exp(t,v)
print par, 'RC = ', 1.0/par[1]
plot(t,v)
show()
