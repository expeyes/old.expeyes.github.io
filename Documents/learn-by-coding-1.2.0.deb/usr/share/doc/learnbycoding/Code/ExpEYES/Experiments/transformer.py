'''
Connect the applied sinewave to A1. Primary Coil from A1 to GND
Secondary coil from A2 to ground
'''
from pylab import *
import expeyes.eyesj, time
p = expeyes.eyesj.open()

t,v,tt,vv = p.capture2_hr(1,2,300,100)
plot(t,v)
plot(tt,vv)
show()

