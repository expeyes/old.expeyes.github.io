'''
Connect electromagnet from OD1 to GND
Loudspeaker from Amplifier Input to GND. Amplifier output to IN1 via diode. 1k resistor from IN1 to GND
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_state(10,1)
raw_input('Attach the Ball to Electromagnet and Press Enter')
print p.clr2rtime(10,3)

