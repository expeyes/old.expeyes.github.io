'''
Measures resistance from SEN and GND
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

#connect LDR  from SEN to GND
print p.measure_res()

