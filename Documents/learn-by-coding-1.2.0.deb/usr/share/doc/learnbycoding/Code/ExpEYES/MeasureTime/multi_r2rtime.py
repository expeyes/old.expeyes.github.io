'''
multi_r2rtime(input, nskip) returns the microseconds elapsed between two rising edges. 
nskip is the number of edges to be skipped in between.
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_sqr1(1000)              # set 1kHz on  SQR1
t = p.multi_r2rtime(6,9)    # 6 is the readback of SQR1. Time of 10 cycles
print t
t = t * 1.0e-6  # to seconds
print 'Frequency = ', (10.0/t)
