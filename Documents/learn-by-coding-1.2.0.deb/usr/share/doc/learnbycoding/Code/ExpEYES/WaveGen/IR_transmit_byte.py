'''
irsend1(byte) Transmits the number using a 38 kHz IR transmission protocol. The information can be received
by an IR receiver connected to MicroHOPE

Connect an IR LED from SQR1 to GND.
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.irsend1(100)   # sends the number 100
