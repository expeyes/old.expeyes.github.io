'''
Connect SINE to A1, with a wire. Connect a diode from A1 to A2 and a 1k resistor from A2 to GND
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

from pylab import *
t,v, tt,vv = p.capture2(1, 2, 300, 100)  # returns two sets of data
plot(t,v)
plot(tt,vv)
show()

