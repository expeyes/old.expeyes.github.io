'''
Connect the Diode between IN1 and GND. A 1K resistor from PVS to IN1.
'''

from pylab import *
import expeyes.eyesj, time
p = expeyes.eyesj.open()

voltage = []
current = []
f = open('diode_iv.dat','w')

v = 0.0
while v <= 5.0:
  va = p.set_voltage(v)
  time.sleep(0.001)
  vd = p.get_voltage(3)
  i = (va-vd)/1.0   # I in milli Amps
  voltage.append(vd)
  current.append(i)
  ss = '%5.3f\t %5.3f'%(vd,i)
  print ss
  f.write(ss+'\n')
  v = v + 0.050    # 50 mV step

plot(voltage, current)
show()
