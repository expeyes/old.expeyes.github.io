'''
Measures the voltage on the selected ADC input (CH0 to CH3) in mV.
First element of the returned value is the PC time stamp
We print the second element.
Connect CH0 to GND and CH1 to 5V and execute this code
'''

import phm, time
p=phm.phm()

p.select_adc(0)      		 # select CH0
print p.get_voltage()[1]
p.select_adc(1)      		 # select CH0
print p.get_voltage()[1]

