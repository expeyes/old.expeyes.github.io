'''
Plots a histogram be reading the voltage at CH0, everytime a pulse is received on CMP.
For testing, connect PWG to CMP,  CH0 to Level shifter output (2.5V)
'''

import phm, time 
p=phm.phm()

p.set_frequency(1000) 

p.clear_hist()
p.start_hist()

print 'waiting..'
time.sleep(1)
print 'done'

p.stop_hist()
v = p.read_hist()

print v
p.plot(v)
raw_input()
p.save_data(v,'hist.dat')

