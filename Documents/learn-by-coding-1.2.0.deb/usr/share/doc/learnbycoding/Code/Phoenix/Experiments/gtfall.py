# Connect the electromagnet from Digital Output D0 to GND.
# Loudspeaker output amplified 101 times and given to Digital Input D0

import phm, time
p=phm.phm()

p.write_outputs(1)
raw_input('Attach the Ball and Press Enter')
print p.clr2rtime(0,0)
