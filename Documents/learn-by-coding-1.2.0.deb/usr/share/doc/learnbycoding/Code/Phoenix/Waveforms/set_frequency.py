'''
This program generates a 1000 Hz square wave on PWG. 
All the frequencies are not possible, sets the nearest possible value and returns it.
To see how it affects, try setting 1500 Hz
'''

import phm, time
p=phm.phm()

print p.set_frequency(1000)
#print p.set_frequency(1500)

