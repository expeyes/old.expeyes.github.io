'''
Connect the DC motor to Non-inverting amplifier input. Rg = 100 Ohm.
Output to CH0 through level shifter.
Oscillate the pendulum and run this code.
'''

import phm, time
p=phm.phm()

DURATION = 5


p.select_adc(0)
p.set_adc_size(2)

f = open('pendulum.dat','w')

start = p.get_voltage_bip()[0]
while 1:
    res = p.get_voltage_bip()
    tm = res[0] - start			# elapsed time
    ss = '%6.3f %6.0f'%(tm,res[1])
    print ss
    f.write(ss+'\n')
    if tm > DURATION:
      break
