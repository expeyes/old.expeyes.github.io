'''
Measures the time interval between rising edges of the specified Digital Input Socket.
By skipping cycles, Time taken for any number of cycles can be measured, to increase the accuracy.

Connect PWG to Digital Input D0 and run this code.

'''

import phm, time
p=phm.phm()


print p.set_frequency(1000)   # period T = 1000 microseconds for 1000 Hz

print p.multi_r2rtime(0,9)    # Skip 9 rising edges to get time for 10 cycles
