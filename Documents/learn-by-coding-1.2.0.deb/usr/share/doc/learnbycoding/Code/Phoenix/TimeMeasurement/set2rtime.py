'''
Measures the time between Setting a Digital Output Socket and a Rising Edge on a Digital
Input Socket.

Connect Output D3 to Input D3 using a 1K resistor. Connect 1uF from Input D3 to GND and run this code.
Due to the capacitor voltage at Input D3 goes up slowly and crosses the 2.4 V level after around 400 usecs

'''

import phm, time
p=phm.phm()

p.write_outputs(0)

print p.set2rtime(3,3)
