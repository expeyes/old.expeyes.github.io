'''
Get the Capacitor discharge data and fit it using the exponetial function. V = Vo.exp(-t/RC)
'''

import phm, phmath
p=phm.phm()

import phm, time
p=phm.phm()

p.select_adc(0)
p.set_adc_size(2)
p.write_outputs(8)
time.sleep(1)
p.enable_set_low(3)
v=p.read_block(200,25,0)

for k in range(len(v)):		# micro to milliseconds. Fit routine has some problem with large numbers
	v[k][0] = v[k][0] * 0.001

res = phmath.fit_exp(v)
frfit = res[1][1]*1.0e6
print frfit

p.plot(res[0])
raw_input()
