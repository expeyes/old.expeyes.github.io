# Sets the Voltage Level on Digital Output Socket D3
# to 0V or 5V in loop. Connect an LED from D3 to GND 
# in series with a 1K resistor.

import phm, time
p=phm.phm()

print 'Press Ctl-C to Exit'
while 1:
	p.write_outputs(8)
	time.sleep(0.5)
	p.write_outputs(0)
	time.sleep(0.5)

