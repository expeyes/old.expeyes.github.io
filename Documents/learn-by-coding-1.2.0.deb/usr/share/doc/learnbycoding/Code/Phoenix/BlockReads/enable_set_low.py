'''
This call has no immediate effect. Subsequent read_block() and
multi_read_block() call will carry out the SET LOW action of the
specified digital output socket before doing the actual block read.

Connect a 1 uF capacitor from CH0 to GND, 1K resistor from D3 to CH0
and run this code.

'''

import phm, time
p=phm.phm()

p.write_outputs(8)          # Set D3 to HIGH
p.enable_set_low(3)	    # make it LOW during the next block read
x = p.read_block(200, 20)
p.disable_set()		    # Remove the effect of enable calls
p.plot(x)
raw_input('Press <Enter>')  # wait for a key press
