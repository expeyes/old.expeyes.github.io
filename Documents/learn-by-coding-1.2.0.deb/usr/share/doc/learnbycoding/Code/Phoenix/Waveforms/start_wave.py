'''
Phoenix can generate waveforms of arbitrary shape on the DAC socket. We need to load the data for one
cycle beforehand. This works only upto 100 Hz and loads the MCU a bit, block reads may become inaccurate
when waveform is generated like this.

Sets a Sawtooth wave on DAC. Observe using a CRO.
'''

import phm, time
p=phm.phm()

v = []
for k in range(100):
	v.append(k)
print v
p.load_wavetable(v)
p.start_wave(20)     # 20 Hz

x=p.read_block(200,500)
p.plot(x)
raw_input('Press Enter to exit')




