# Sets the Voltage Levels on the four Digital Output Sockets
# to 0V or 5V. Levels are specified using a 4 bit number.
# n = 15 (binary 1111) sets all sockets to 5V

import phm
p=phm.phm()

n = 15
p.write_outputs(n)
