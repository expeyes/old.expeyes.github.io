'''
Digitize powerline pickup and fit the data to extract the frequency.
Connect a piece of wire to CH0
Connect Any Digital Input Socket to GND when you see a stable trace
'''

import phm, phmath
p=phm.phm()

p.select_adc(0)

while p.read_inputs() == 15:
	data = p.read_block(200, 500)
	p.plot_data(data)

 
res = phmath.fit_sine(data)
frfit = res[1][1]*1.0e6
print 'Frequency = %5.2f Hz'%frfit

p.plot(res[0])
#p.set_scale(0,-5,1,5)
raw_input()
