'''
Connect the Light Barrier output to Digital Input D3.
Let the pendulum oscillate through the barrier and start the program.

Period of Oscillation is measured and 'g' calculated 
'''

import phm, math
p=phm.phm()

length = 15.0			# length of the rod pendulum
pisqr = math.pi * math.pi

for i in range(50):
  T = p.multi_r2rtime(3,1) * 1.0e-6    # convert from micro second to second
  if T < 0:
	print 'Timeout Error'
  else:
        g = 4.0 * pisqr * 2.0 * length / (3.0 *  T * T)
        print i, ' ',T, ' ', g

