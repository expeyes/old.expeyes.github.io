'''
This call has no immediate effect. Subsequent read_block() and
multi_read_block() call will generate a HIGH PULSE on the specified
Digital Output Socket by taking it HIGH and then LOW.
The duration of the pulse is set by the set_pulse_width() call

Connect a 1uF capacitor from CH0 to GND, connect CH0 to D3 through a 1K resistor.
Explain the discharge curve starting from nearly 1V amplitude (try changing width, max=255).

'''

import phm, time
p=phm.phm()

p.write_outputs(0)          # Set D3 to HIGH
p.set_pulse_width(250)      # 100 usec pulse
p.enable_pulse_high(3)
x = p.read_block(200, 20)
p.disable_set()		    # Remove the effect of enable calls
p.plot(x)
raw_input('Press <Enter>')  # wait for a key press
