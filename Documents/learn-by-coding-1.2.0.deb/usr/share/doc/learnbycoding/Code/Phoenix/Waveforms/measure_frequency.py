'''
Connect PWG to CNTR and run this code. You can connect external waveforms in 0 to 5V range to CNTR input
for frequency measurement. Resolution is 1 Hz
'''

import phm, time
p=phm.phm()

print p.set_frequency(1000)
print p.measure_frequency()

