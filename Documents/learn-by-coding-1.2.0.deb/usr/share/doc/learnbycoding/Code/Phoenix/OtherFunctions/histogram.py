'''
Histogram Generation.

'''

import phm, time
p=phm.phm()

p.set_frequency(1000)
p.clear_hist()
p.start_hist()
time.sleep(1)
p.stop_hist()
v = p.read_hist()
f = open('hist.dat','w')
for k in v:
    ss = '%d %d\n'%(k[0], k[1] )
    f.write(ss)

