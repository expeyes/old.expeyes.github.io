'''
Connect PWG to CH1 . 1K resistor from CH1 to CH0. 1 uF capacitor from CH0 to GND
Watch the original waveform and the integrated one for different frequency and RC values.
'''

import phm
p = phm.phm()

print p.set_frequency(1000)

p.add_channel(0)
p.add_channel(1)

print 'Ground any Digital Input to Exit...'
while p.read_inputs() == 15:
	data = p.multi_read_block(100, 20)
	p.plot_data(data)
