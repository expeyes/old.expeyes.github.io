'''
Measures the time interval between a rising edge (0V -> 5V) to a falling edge (5V -> 0V). The signals
are applied to Digital Input Sockets. One can apply both edges to the same Socket also.

Connect PWG to Digital Input D0 and run this code.

'''

import phm, time
p=phm.phm()


print p.set_frequency(1000)   # period T = 1000 microseconds for 1000 Hz

print p.r2ftime(0,0)          # Both edges are on Socket D0

print p.f2rtime(0,0)          # falling edge to rising edge also

