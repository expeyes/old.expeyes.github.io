'''
Velocity of Sound by Piezo transmitter and receiver. Connect Digital Output D3 to Transmitter piezo.
Receiver piezo output is amplified  by 10000 ( two 100x amplifiers in series) and given to
Digital Input D3 throgh a 1K resistor.
Better results obtained if the Digital Output D3 singal is 
'''

import phm
p=phm.phm()

p.write_outputs(0)
p.set_pulse_width(13)
p.set_pulse_polarity(0)
p.enable_pulse_high(3)	# modify read block to send a pulse

for x in range(10):
  print p.pulse2rtime(3,3)

