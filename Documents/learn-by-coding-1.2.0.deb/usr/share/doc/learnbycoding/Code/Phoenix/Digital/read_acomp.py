# Returns 1 if the voltage level on CMP is < 1.23 V, else 0

import phm, time
p=phm.phm()

print p.read_acomp()

