from Tkinter import *
import phm, time, math, sys
p=phm.phm()

base = []
wavelen = [400., 430., 470., 505., 525., 570., 590., 610., 635., 660.]
NLED = 10

def measure(n):
	p.write_outputs(n)
	time.sleep(0.1)
	res = p.get_voltage()[1]
	p.write_outputs(15)
	return res

def do_base():
	global base, wavelen, NLED
	base = []
	clear()
	for n in range(NLED):
		val = measure(n)
		base.append(val)
		ss = '%8.0f nm %8.3f V\n'%(wavelen[n],val*0.001)
		data.insert(END,ss)
	msg.config(text='Base Done', fg = 'black')


def do_sample():
	global base, wavelen, NLED
	if base == [] :
		msg.config(text='Do Base First', fg = 'red')
		return
	clear()
	data.insert(END,'Wavelength         Base     Sample  Tran (%)  Absorbance\n')
	for n in range(NLED):
		val = measure(n)
		tr = val / base[n] * 100
		ab = 2.0 - math.log10(tr)
		ss = '%8.0f nm  %8.3f V %8.3f V %8.1f %%  %8.3f\n'\
			%(wavelen[n], base[n]*0.001, val*0.001, tr, ab)
		data.insert(END,ss)
	msg.config(text='Sample Done', fg = 'black')

def clear():
	data.delete(1.0, END)  

def quit():
	sys.exit()

root = Tk()
f1 = Frame(root)
f1.pack()
data = Text(f1, width = 60, height = 11)
data.pack()

Start = Button(root,text = 'Base Solution', command = do_base)
Start.pack(side=LEFT)

Start = Button(root,text = 'Sample Solution', command = do_sample)
Start.pack(side=LEFT)

Start = Button(root,text = 'Clear', command = clear)
Start.pack(side=LEFT)

msg = Label(root,text = '')
msg.pack(side=LEFT)

Start = Button(root,text = 'Quit', command = quit)
Start.pack(side=RIGHT)

root.title('Phoenix Based Colorimeter')
root.mainloop()

