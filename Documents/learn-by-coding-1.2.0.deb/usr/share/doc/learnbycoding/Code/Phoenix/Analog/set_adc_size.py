'''
Sets the ADC resolution. Connect some known voltage to CH0
'''

import phm, time
p=phm.phm()

p.select_adc(0)      		 # select CH0

p.set_adc_size(1)		 # ADC in 8 bit mode
print p.get_voltage()[1]
p.set_adc_size(2)		 # in 10 bit mode
print p.get_voltage()[1]

