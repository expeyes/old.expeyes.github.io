'''
Bipolar signal are connected to ADC inputs through the Level Shifter
amplifiers. get_voltage_bip() returns the voltage at the input of
the level shifter.
Connect GND to Level shifter input and output to CH0, should get 2.5 V
'''

import phm, time
p=phm.phm()

p.select_adc(0)      		 # select CH0
print p.get_voltage_bip()[1]

