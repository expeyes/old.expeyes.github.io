'''
Reads a waveform from CH0, plots the wave and it Fast Fourier Transform.
Uses a 1000 Hz squarewave from PWG as a test signal.
While using with Analog Box, Connect the GND of Phoenix and Analog Box. 
Connect Sinewave output to CH0 through a level shifter. 
'''

import phm, phmath
p=phm.phm()


p.select_adc(0)
p.set_adc_size(1)
data = p.read_block(800,40,1) 
p.save_data(data,'amwave.dat')
res = phmath.fft(data)
p.save_data(res,'amfft.dat')
p.plot(res)			
p.auto_scale(res)
raw_input()			# wait for a Keypress
