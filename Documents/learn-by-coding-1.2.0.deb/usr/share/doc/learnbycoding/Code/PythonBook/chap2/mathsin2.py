Example math2.py

import math as m   # Give another madule name
print m.sin(0.5)   # Refer by the new name
