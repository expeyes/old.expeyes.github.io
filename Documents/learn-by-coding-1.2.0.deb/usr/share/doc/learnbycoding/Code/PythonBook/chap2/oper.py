x = 2
y = 4
print x + y * 2
s = 'Hello '
print s + s
print 3 * s
print x == y
print y == 2 * x 
