x = input('Enter a number ')
try:
    print 10.0/x
except:
    print 'Division by zero not allowed'
