from cpoint import *

p1 = Point(5,5)
rp1 = colPoint(2,2,'red')

print p1
print rp1
print rp1 + p1
print rp1.dist()

