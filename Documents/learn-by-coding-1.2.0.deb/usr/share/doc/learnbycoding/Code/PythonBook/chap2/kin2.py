x,y = input('Enter x and y separated by comma ')
print 'The sum is ', x + y
s = raw_input('Enter a decimal number ')
a = float(s)
print s * 2    # prints string twice
print a * 2    # converted value times 2
