#Example rfile.py

f = open('test.dat' , 'r')
print f.read()
f.close()
