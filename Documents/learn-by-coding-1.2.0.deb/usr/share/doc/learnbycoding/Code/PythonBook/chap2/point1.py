from point import *

origin = Point()
print origin
p1 = Point(4,4)
p2 = Point(8,7)
print p1
print p2
print p1 + p2
print p1 - p2
print p1.dist()

