#Example sine.py

import math
x = 0.0
while x < math.pi * 4:
    print x , math.sin(x)
    x = x + 0.1