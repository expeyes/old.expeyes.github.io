#Example: table.py

x = 1
while x <= 10:
    print x * 8
    x = x + 1
