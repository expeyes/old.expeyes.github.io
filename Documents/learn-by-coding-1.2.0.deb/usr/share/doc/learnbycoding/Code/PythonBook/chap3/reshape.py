#Example reshape.py

from numpy import *
a = arange(20)
b = reshape(a, [4,5])
print b
