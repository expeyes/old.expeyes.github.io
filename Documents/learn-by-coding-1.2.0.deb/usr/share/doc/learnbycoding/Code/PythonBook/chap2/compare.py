x = raw_input('Enter a string ')
if x == 'hello':
    print 'You typed ', x
    