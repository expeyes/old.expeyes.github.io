#Example func.py

def sum(a,b):    # a trivial function
    return a + b

print sum(3, 4)
