def power(mant = 10.0, exp = 2.0):
    return mant ** exp   
    
print power(5., 3)
print power(4.)      # prints 16
print power(exp=3)   