#Example: forloop.py

a = 'my name'
for ch in a:
    print ch

b = ['hello', 3.4, 2345, 3+5j]
for item in b:
    print item
