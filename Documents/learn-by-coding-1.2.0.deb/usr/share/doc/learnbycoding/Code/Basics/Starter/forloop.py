#Example: forloop.py

name = 'forloop'
for ch in name:
    print ch

