# Difference between lists & arrays

x = [1,2,3]
print x
print 'List multiplication: ', 2*x

from numpy import *

a = array(x,'float')
print type(a[1])
print 'Array multiplication: ', 2*a

