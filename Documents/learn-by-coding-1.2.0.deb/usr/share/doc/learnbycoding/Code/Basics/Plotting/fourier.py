from pylab import *

x = linspace(-pi, pi, 500)    # linear space
y = sin(x) + sin(3*x)/3
plot(x,y)
show()

