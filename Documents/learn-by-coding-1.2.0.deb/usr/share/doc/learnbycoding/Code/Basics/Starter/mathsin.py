#Importing a module

import math

print math.sin(0.5) # module_name.method_name 

from math import *
sin(1)
