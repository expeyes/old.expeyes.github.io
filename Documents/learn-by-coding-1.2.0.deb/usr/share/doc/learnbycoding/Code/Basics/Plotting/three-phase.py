from pylab import *

x = linspace(0,2*pi,200)
Vp = 230 * sqrt(2)

p1 = Vp*sin(x)
p2 = Vp*sin(x + 120 *pi/180)
p3 = Vp*sin(x + 240 *pi/180)

plot(x,p2-p1)
plot(x,p1)
plot(x,p2)
plot(x,p3)
show()
