#Example: area.py , A = p * r^2

pi = 3.1416
r = input('Enter Radius ')
a = pi * r ** 2  
print 'Area = ', a
