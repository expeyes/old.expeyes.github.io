# pendulum simulation

from scipy import integrate
from pylab import *

omega0 = 0
theta0 = pi/20  # radians
y0 = [omega0, theta0] #initial values

t = linspace(0, 10, 400) # integrate from 0 to 20 seconds

def simple_pendulum_deriv(x, t, g = 9.81, mu = 0.5): 
    nx = np.zeros(2)
    nx[0] = x[1]
    nx[1] = -(g * sin(x[0])) - mu*x[1]
    return nx

r = integrate.odeint(simple_pendulum_deriv, y0, t)

subplot(211),plot(t,r[:,1]),xlabel('Angle'),ylabel('')
subplot(212),plot(t,r[:,0],'r'),xlabel('Angular velocity'),ylabel('')
show()
