from pylab import *

NP = 4
x = array([0,3,6,9])
data = array([5,14,22,32])
print x,data

xbar = mean(x)
ybar = mean(data)
b = sum(data*(x-xbar)) / sum(x*(x-xbar))
a = ybar - xbar * b
print a,b

y = a + b * x
plot(x,y)
plot(x,data,'ob')
show()

