from numpy import *
from mayavi import mlab
from scipy import special

l = 1
m = 0
polar = linspace(0,pi,200)
azimuth = linspace(0, 2*pi,200)
phi,th = meshgrid(polar, azimuth)

r =  special.sph_harm(m,l,polar,azimuth).real

x = r*sin(phi)*cos(th)
y = r*cos(phi)
z = r*sin(phi)*sin(th)
mlab.mesh(x, y, z)

mlab.show()

