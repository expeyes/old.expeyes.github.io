from numpy import *
from mayavi.mlab import *
from scipy import special

def f(x, y):
	r = sqrt(x**2 + y**2)
	return 5*special.j0(r)

x, y = mgrid[-10.0:10.0:100j, -10.0:10.0:100j]
s = surf(x, y, f)

show()
