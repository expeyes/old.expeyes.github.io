import expeyes.eyes as eyes
p = eyes.open()
print p.read_inputs()

