import compileall
compileall.compile_dir('/usr/share/eyes17', force=True)
