PQT5 = False
print("Qt version:", QT_VERSION_STR)
