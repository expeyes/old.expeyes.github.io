print  get_voltage('A1')
print  get_voltage('A2')
print  get_voltage('A3')

