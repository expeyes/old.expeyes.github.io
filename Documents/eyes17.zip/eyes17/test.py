import subprocess
subprocess.call(['xterm', '-e', 'python scope.py'])
