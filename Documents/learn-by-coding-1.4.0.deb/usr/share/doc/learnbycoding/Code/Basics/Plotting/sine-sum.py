from pylab import *

x = linspace(0, pi, 500)
f = 10
y1 = sin(2*pi*f*x)

f = 11
y2 = sin(2*pi*f*x)

plot(x,y1+y2)
plot(x,y1)
plot(x,y2)
show()

