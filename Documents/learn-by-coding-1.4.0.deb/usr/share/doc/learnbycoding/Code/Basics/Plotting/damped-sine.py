from pylab import *

x = linspace (0, 6*pi, 200)  # linear space, equidistant points
y = sin(x) * exp(-0.2*x)
ylim([-1,1])
plot(x,y)
show()
