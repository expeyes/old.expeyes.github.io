#Matrices

from numpy import *
n = array([5,6])
m = array([[1,2], [3,4]])
print n
print m

print zeros([3,3])
print ones([3,3])
print arange(0, 1.1,.1)
print linspace(0,1,11)

