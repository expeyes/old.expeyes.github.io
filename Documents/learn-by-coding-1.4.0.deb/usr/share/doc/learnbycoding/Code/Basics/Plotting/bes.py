from pylab import *
from scipy import special

x = linspace(0,20,200)
y = special.j0(x)
ylim([-1,1])
plot(x,y)
show()

