#read data

from numpy import *
a,b = loadtxt('data.txt', unpack= True)
print a
print b


