from pylab import *

x, y = np.ogrid[-1.5:0.5:500j, -1:1:500j]
z = x + 1j * y

julia = zeros(z.shape)
c = 0.7 + .5j

for i in range(20):
    z = z ** 2 - c 
    julia += 1 / (z * conj(z) > 4) * float(2 + i)#

imshow(julia)
show()
