# Arithmetic of list data type

x = [1,2,3]

print 2*x

from numpy import *

a = array(x)
print a *2
