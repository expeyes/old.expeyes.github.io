from mayavi.mlab import *
from scipy import special
import numpy as np

n = 2
k = 3
t = 1

def drumhead_height(n, k, distance, angle, t):
	kth_zero = special.jn_zeros(n, k)[-1]
	return np.cos(t) * np.cos(n*angle) * special.jn(n, distance*kth_zero)

theta = np.linspace(0, 2*np.pi, 100)
radius = np.linspace(0, 2, 50)
x = np.array([r * np.cos(theta) for r in radius])
y = np.array([r * np.sin(theta) for r in radius])
z = 5 * np.array([drumhead_height(n, k, r, theta, t) for r in radius])
mesh(x, y, z)
show()
