# Usage of if, elif , else

x = input('Enter a number ')
if x > 5:
    print 'Greater than 5'
elif x <  5:
    print 'Less than 5'
else:
    print 'Equal to 5'

    
