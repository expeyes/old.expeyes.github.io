'''
Connect the Diode between CH0 and GND. A 1K resistor from DAC to CH0. Run the code.
'''

import phm, time
p=phm.phm()

p.set_adc_size(2)
p.set_adc_delay(200)

data = []

va = 0.0
while va <= 5000.0:
  p.set_voltage(va)
  time.sleep(0.001)
  vb = p.zero_to_5000()[1]
  ib = (va-vb)/1000.0
  data.append([vb,ib])
  print '%5.1f\t %5.3f'%(vb,ib)
  va = va + 19.6

p.save_data(data,'iv.dat')
p.window()
p.line(data)
p.auto_scale(data)
raw_input()

