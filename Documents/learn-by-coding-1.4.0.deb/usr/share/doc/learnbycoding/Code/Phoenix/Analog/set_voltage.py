# Sets the voltage on the DAC Socket between 0 mV and 5000 mV
# in 256 steps. The quality of DC can be improved by an RC filter.

import phm, time
p=phm.phm()

p.set_voltage(2000)

