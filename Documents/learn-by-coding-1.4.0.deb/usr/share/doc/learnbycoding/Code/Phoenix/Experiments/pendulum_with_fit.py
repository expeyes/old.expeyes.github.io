'''
Connect the DC motor to Non-inverting amplifier input. Rg = 100 Ohm.
Output to CH0 through level shifter.
Oscillate the pendulum and run this code.
'''

import phm, phmath, time
p=phm.phm()

DURATION = 5
p.select_adc(0)
p.set_adc_size(2)

data = []

start = p.get_voltage_bip()[0]
while 1:
    res = p.get_voltage_bip()
    tm = res[0] - start			# elapsed time
    data.append([tm,res[1]])            # Add data to the list
    if tm > DURATION:
      break

res = phmath.fit_dsine(data)
frfit = res[1][1]*1.0e6
print frfit

p.plot(res[0])
p.save_data(res[0])
#p.set_scale(0,-5,5,5)
raw_input()

