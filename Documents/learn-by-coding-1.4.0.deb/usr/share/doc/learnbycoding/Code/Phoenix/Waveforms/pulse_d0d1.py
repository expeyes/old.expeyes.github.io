'''
Generates low frequency squarewave on Digital Output Sockets D0 and D1 simultaneously.

Connect D1 to CNTR
'''

import phm, time
p=phm.phm()

p.pulse_d0d1(10)     # 10 Hz
print p.measure_frequency()


