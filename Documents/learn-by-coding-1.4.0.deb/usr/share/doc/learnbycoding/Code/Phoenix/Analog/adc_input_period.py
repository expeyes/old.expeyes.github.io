'''
Measures the Time period of a 0 to 5V amplitude square wave connected
to any ADC input.
Connect PWG to CH0 and run this code
'''

import phm, time
p=phm.phm()

p.set_frequency(1000)
print p.adc_input_period(0)  # measurement on CH0


