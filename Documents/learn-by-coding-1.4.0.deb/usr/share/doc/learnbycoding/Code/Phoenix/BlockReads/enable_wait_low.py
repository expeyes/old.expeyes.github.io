'''
This call has no immediate effect. Subsequent read_block() and
multi_read_block() call will wait for a LOW LEVEL on the specified
Digital Input Socket. This feature is used for digitizing transients

Connect Digital Input D3 to CH0. Start the program and connect them
to PWG. The plot will appear only when you connect it.
'''

import phm, time
p=phm.phm()

p.set_frequency(1000)

p.write_outputs(8)          # Set D3 to HIGH
p.enable_wait_low(3)	    # wait for a LOW on Digital Input D3
x = p.read_block(200, 20)
p.disable_wait()		    # Remove the effect of enable calls
p.plot(x)
raw_input('Press <Enter>')  # wait for a key press
