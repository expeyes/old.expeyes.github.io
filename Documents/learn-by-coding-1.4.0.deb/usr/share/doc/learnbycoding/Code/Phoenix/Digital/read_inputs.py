# Obtain the Voltage Levels on the four Digital Input Sockets
# in a 4 bit number.

import phm
p=phm.phm()

print p.read_inputs()
