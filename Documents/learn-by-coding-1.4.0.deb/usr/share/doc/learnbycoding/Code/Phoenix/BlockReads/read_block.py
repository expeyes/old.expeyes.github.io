'''
Measures the voltage on the selected channel a specified number
of times. Minimum Time interval between two reads is 10 microseconds
Connect PWG to CH0 and run this.
'''

import phm, time
p=phm.phm()

p.set_frequency(1000)

p.select_adc(0)
print p.read_block(10, 100)  # 10 time, 100 usec between measurements

