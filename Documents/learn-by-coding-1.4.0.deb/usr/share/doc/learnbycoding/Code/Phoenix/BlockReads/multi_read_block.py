'''
Samples voltages from multiple channels in a single call. The channels
are selected and deselected by add_channel() and del_channel() calls.
The return value is a 10 element list. Each element is [t, VCH0, VCH1]
'''

import phm, time
p=phm.phm()

p.set_frequency(1000)

p.add_channel(0)
p.add_channel(1)
print p.multi_read_block(10, 100)  # 10 time, 100 usec in between

