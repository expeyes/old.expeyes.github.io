'''
set_sqr1_dc(voltage) generate 7.8kHz Pulse Width Modulated waveform, that can be filtered 
by an RC network to obtain the desired DC voltage
set_sqr2_dc() does the same for SQR2 output

Connect SQR1 to IN1 via an RC network. 1k from SQR1 to IN1 and 100 uF from IN1 to GND.
'''

import expeyes.eyesj, time
p = expeyes.eyesj.open()

from pylab import *
p.set_sqr1_dc(2.5)        
time.sleep(0.2)    # Allow some time to stabilize the voltage    
print p.get_voltage(3)

t,v = p.capture(3, 300, 100)   # capture to view the ripple in the output
plot(t,v)
show()

