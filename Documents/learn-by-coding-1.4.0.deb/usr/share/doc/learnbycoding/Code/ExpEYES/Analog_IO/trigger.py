'''
Connect SINE to A1, with a wire
Change the trigger value
'''

from pylab import *
import expeyes.eyesj
p = expeyes.eyesj.open()


p.set_trig_source(1)   # Set A1 as trigger source
trlevel = 1.0
p.set_trigger(int(trlevel * 4095/10.0 + 2048))    # Set trigger level from 0 to 4095 ( -5V to +5V)
t,v = p.capture(1, 300, 100)
plot(t,v)

trlevel = -1.0
p.set_trigger(int(trlevel * 4095/10.0 + 2048))    # Set trigger level from 0 to 4095 ( -5V to +5V)
t,v = p.capture(1, 300, 100)
plot(t,v)

show()
