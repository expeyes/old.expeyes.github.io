'''
Connect different waveforms like Sinusoidal, Triangular etc to A1 and plot their statistical
distribution, by random sampling.
'''
NP = 1000   # increase this for better histogram

from pylab import *
import expeyes.eyesj, time
p = expeyes.eyesj.open()

va = []
for k in range(NP):
	v = p.get_voltage(1)
	print v
	va.append(v)
	time.sleep(rand()*0.01)

hist(va, 40, normed=1)
show()

