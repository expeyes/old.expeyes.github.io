'''
Measures capacitance in the range of pico Farads
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

#connect Capacitor from IN1 to GND
print p.measure_cap()

