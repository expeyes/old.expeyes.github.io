'''
Sets a digital output to a specified level before capturing the waveform
Make connections for RC, RL or RLC response. Code remains the same
'''

from pylab import *
import expeyes.eyesj
p = expeyes.eyesj.open()

#Connect 1k resistor from OD1 to A1 and a 1uF capacitor from A1 to ground
p.set_state(10,1)         # OD1 to HIGH
p.enable_set_low(10)
t,v = p.capture_hr(1, 400, 10)
plot(t,v)
show()
