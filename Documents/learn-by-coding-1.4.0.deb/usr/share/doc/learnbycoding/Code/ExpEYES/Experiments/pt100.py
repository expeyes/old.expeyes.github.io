'''
Connect PT100 from CCS to GND. Connect CCS to IN1 via an external Amplifier with gain of around 30
'''
import expeyes.eyesj, math, time
p = expeyes.eyesj.open()

gain = 30.0 		# amplifier gain
offset = 0.0		# Amplifier offset, measured with input grounded
current = 1.0	# CCS output 1 mA, need to put the actual value

def v2t(v):			# Convert Voltage to Temperature for PT100
	r = v / gain / (current * 1.0e-3)  # mA to Ampere
	r0 = 100.0
	A = 3.9083e-3
	B = -5.7750e-7
	c = 1 - r/r0
	b4ac = math.sqrt( A*A - 4 * B * c)
	t = (-A + b4ac) / (2.0 * B)
	print current, gain, v, r, t
	#print r,t
	return t

p.set_state(11,1)   # enable CCS

print 'Data is also written to the file pt100.dat'
of = open('pt100.dat','w')

strt = p.get_voltage_time(3)[0]   # starting time stamp
for x in range(100):
	res = p.get_voltage_time(3)
	temp = v2t(res[1])
	print res[1], temp
	ss = '%5.2f %5.2f' %(res[0]-strt, temp)
	of.write(ss+'\n')
	print ss
	time.sleep(1.0)
