'''
Connect PVS to the desired input, IN1 or IN2
Change PVS output to find out the voltage required for HIGH and LOW levels
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_voltage(1)
print p.get_state(3)   # level on IN1
p.set_voltage(2.5)
print p.get_state(3)   # level on IN1
