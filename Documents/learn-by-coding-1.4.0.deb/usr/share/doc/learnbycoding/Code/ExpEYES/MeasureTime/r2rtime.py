'''
r2rtime(in1, in2) returns the microseconds elapsed from a rising edge on input1 to a rising edge of input2, 
they must be distinct. This function can be used to measure delays.
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

p.set_sqrs(1000, 20)    # set 1kHz on both SQR1 and SQR2, with a 20% phase shift
print p.r2rtime(6,7)    # 6 is the readback of SQR1, 7 of SQR2

