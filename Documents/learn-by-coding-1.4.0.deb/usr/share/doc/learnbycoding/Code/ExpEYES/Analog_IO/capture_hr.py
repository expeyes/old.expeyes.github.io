'''
Connect SINE to A1, with a wire
'''

import expeyes.eyesj
p = expeyes.eyesj.open()

from pylab import *
t,v = p.capture(1, 300, 100)
plot(t,v)
t,v = p.capture_hr(1, 300, 100)
plot(t,v, color='red')
show()
#maximize the plot to view the difference
