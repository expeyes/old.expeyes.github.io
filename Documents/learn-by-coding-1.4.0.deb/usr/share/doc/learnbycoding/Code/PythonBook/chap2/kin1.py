x = input('Enter an integer ')
y = input('Enter one more ')
print 'The sum is ', x + y
s = raw_input('Enter a String ')
print 'You entered ', s
