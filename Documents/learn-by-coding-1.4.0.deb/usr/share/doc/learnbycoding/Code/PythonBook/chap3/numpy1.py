#Example numpy1.py

from numpy import *
x = array( [1,2] )   # Make array from list
print x , type(x)
