a = [3, 3.5, 234]   # make a list
print a[0]
a[1] = 'haha'       # Change an element
print a
