#Example numpy2.py

from numpy import *

a = arange(1.0, 2.0, 0.1) # start, stop & step
print a
b = linspace(1,2,11) 
print b
c = ones(5)         
print c
d = zeros(5)
print d
e = random.rand(5)
print e
