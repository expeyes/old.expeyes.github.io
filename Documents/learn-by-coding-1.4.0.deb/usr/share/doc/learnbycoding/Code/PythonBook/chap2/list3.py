a = []          # make an empty list
a.append(3)     # Add an element
a.insert(0,2.3) # insert 2.3 as first element
print a, a[0]
print len(a)