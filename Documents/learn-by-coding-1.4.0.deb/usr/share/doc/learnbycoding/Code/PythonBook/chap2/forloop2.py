#Example: forloop2.py

mylist = range(5)
print mylist

for item in mylist:
    print item
