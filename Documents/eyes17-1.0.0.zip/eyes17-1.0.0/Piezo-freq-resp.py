'''
expEYES program
Author  : Ajith Kumar B.P, bpajith@gmail.com
License : GNU GPL version 3
'''
import expeyes.eyes17 as eyes, expeyes.eyeplot17 as eyeplot, expeyes.eyemath17 as eyemath, numpy as np
import time, sys, numpy
VER = sys.version[0]
if VER == '3':
	from tkinter import *
else:
	from Tkinter import *

import gettext
gettext.bindtextdomain("expeyes")
gettext.textdomain('expeyes')
_ = gettext.gettext


TIMER = 100
WIDTH  = 600   # width of drawing canvas
HEIGHT = 400   # height    

NP = 400
tg = 20
fmin = 100.0
freq = fmin
fmax = 5000.0
step = 40
vpeak = 0			# Assume as 0
fpeak = fmin
history = []		# Data store
trial = 0			# trial number
data = [ [], [] ]	# Current & Voltage
index = 0
running = False

def rmsval(x):
	return np.sqrt(np.mean(x**2))

def start():
	global running, NP, freq, fmin, data, index
	running = True
	data = [ [], [] ]
	index = 0
	freq = fmin
	ph.set_sine(fmin)
	root.after(10,update)

def update():					# Called periodically by the Tk toolkit
	global running, NP, tg, freq, fmax, fpeak, vpeak, history, data, index, trial
	if running == False:
		return
	fr = ph.set_sine(freq)
	time.sleep(0.1)
	freq += step
	t,v = ph.capture1('MIC', NP, tg)
	rmsv = rmsval(v)
	data[0].append(fr)
	data[1].append(rmsv)
	if rmsv > vpeak:
		vpeak = rmsv
		fpeak = fr
	if fr > fmax:
		running = False
		history.append(data)
		trial += 1
		g.delete_lines()
		for k in range(len(history)):
			g.line(history[k][0], history[k][1], k)
		vmax = max(data[1])
		R.config(text='Fo = %5.0f Hz'%fpeak)
		ph.set_sqr1(0)
		return

	if index > 1:			# Draw the line
		g.delete_lines()
		g.line(data[0], data[1], trial)
	index += 1
	root.after(TIMER, update)

def xmgrace():		# Send the data to Xmgrace
	global history
	try:
		import pygrace
	except:
		return
	pg = pygrace.grace()
	for dat in history:
		pg.plot(dat[0],dat[1])
		pg.hold(1)			# Do not erase the old data
	pg.xlabel(_('Frequency'))
	pg.ylabel(_('Amplitude'))
	pg.title(_('Frequency response curve'))

def save():
	global history, running
	if running == True:
		return
	s = e1.get()
	if s == '':
		return
	f = open(s, 'w')
	for dat in history:
		for k in range(len(dat[0])):
			f.write('%5.3f  %5.3f\n'%(dat[0][k], dat[1][k]))
		f.write('\n')
	f.close()
	msg.config(text = _('Data saved to file ')+s)

def clear():
	global history, trial, running
	if running == True:
		return
	g.delete_lines()
	history = []
	trial = 0

def quit():
	ph.set_sqr1(0)
	sys.exit()


ph = eyes.open()
root = Tk()
Canvas(root, width = WIDTH, height = 5).pack(side=TOP)  # Some space at the top
g = eyeplot.graph(root, width=WIDTH, height=HEIGHT)	# make plot objects using draw.disp
g.setWorld(fmin, 0, fmax, 5.0,_('Freq'),_('Amp'))

cf = Frame(root, width = WIDTH, height = 10)
cf.pack(side=TOP,  fill = BOTH, expand = 1)

b1 = Button(cf, text = _('START'), command = start)
b1.pack(side = LEFT, anchor = N)
b3 = Button(cf, text = _('SAVE to'), command = save)
b3.pack(side = LEFT, anchor = N)
filename = StringVar()
e1 =Entry(cf, width=15, bg = 'white', textvariable = filename)
filename.set('Piezo-freq-resp.dat')
e1.pack(side = LEFT)
R = Label(cf,text=_('Fmax = '))
R.pack(side=LEFT)
b5 = Button(cf, text = _('QUIT'), command = quit)
b5.pack(side = RIGHT, anchor = N)
b4 = Button(cf, text = _('CLEAR'), command = clear)
b4.pack(side = RIGHT, anchor = N)
b5 = Button(cf, text = _('Grace'), command = xmgrace)
b5.pack(side = RIGHT, anchor = N)

mf = Frame(root, width = WIDTH, height = 10)
mf.pack(side=TOP,  fill = BOTH, expand = 1)
msg = Label(mf,text='', fg = 'blue')
msg.pack(side=LEFT)

t =  _('Frequency Response Curve of Piezo Buzzer')
eyeplot.pop_help('Piezo-freq-resp',t)
root.title(t)
root.mainloop()

