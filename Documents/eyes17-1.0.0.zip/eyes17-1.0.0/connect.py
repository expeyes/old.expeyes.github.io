import expeyes.eyes17
p=expeyes.eyes17.open()
